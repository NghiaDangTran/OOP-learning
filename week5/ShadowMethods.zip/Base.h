#pragma once

class Base
{
	private:
		int baseInt;
		
	public:
		//Constructors
		Base(int);
		
		//Instance methods
		virtual void print();
};