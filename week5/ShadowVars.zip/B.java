public class B extends A
{	
	public int number;
		
	public String toString()
	{
		return "This method is from class B, number = " + number + " and super.number = " + super.number;
	}
}