#pragma once

#include "A.h"

class B : public A
{
	public:
		B();
		void print();
};