#include "C.h"

#include <iostream>

using namespace std;

int main()
{
	A* var1 = new C;
	var1->print();
	
	return 0;
}