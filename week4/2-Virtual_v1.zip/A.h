#pragma once

class A
{
	protected:
		int number;
		
	public:
		A();
		virtual void print();
};