#pragma once

#include "B.h"

class C : public B
{
	public:
		C();
		void print();
};

